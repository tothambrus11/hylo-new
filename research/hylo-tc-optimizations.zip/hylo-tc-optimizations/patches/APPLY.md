# Applying the patch series

The patches apply on top of branch `tc/research` of `tothambrus11/hylo-new`. That branch already contains the tc-bench harness, the experiment flags and the first-round flags (`names`, `unify`, `solver`, `index`, `absmodel`, `loopcheck`).

```bash
git checkout -b tc/final origin/tc/research
```

```bash
git am /path/to/hylo-tc-optimizations/patches/*.patch
```

```bash
git submodule update --init
```

```bash
swift build -c release --product tc-bench
```

A clean build takes 16–28 minutes on 4 cores; an incremental one, 2–4 minutes. Build one worktree at a time: parallel release builds can exhaust memory.

## Running

```bash
HYLO_TC_EXPERIMENTS=occurs,fixsubst,eqsolve,extorder,arrowenv,eqmgu,givencheck,budget,symindex,coesrc,traitindex,memberskip,unify,index,absmodel,absquotient,typevec,reifymemo .build/release/tc-bench program.hylo
```

Other switches:
- `HYLO_TC_EXPERIMENTS=…,trace` prints the derivations of completed resolutions.
- `HYLO_TC_BUDGET` sets the `budget` limit (default 100000).
- `HYLO_TC_MAXDEPTH` sets the depth cap (default 10).
- `HYLO_TC_ABSDEPTH` sets the depth of the abstract model (default 2).

## The patches

| Patch | Content |
|---|---|
| 0001 | `symindex`, `memberindex` (later replaced) and `coesrc`; `absmodel` depth defaults to 2 |
| 0002 | `traitindex` and `memberskip`, replacing `memberindex` |
| 0003 | `memberskip` also skips when `applies` only reads memoized types |
| 0004 | `absmodel`: the three unsound spots found by review 1 |
| 0005 | `coercememo` (negative result), `HYLO_TC_MAXDEPTH` |
| 0006 | `typevec` |
| 0007 | soundness fixes `occurs`, `fixsubst`, `eqrefute` (retired) and `cyclecut` (retired); the trace |
| 0008 | `eqsolve` and `extorder` |
| 0009 | fixes from review 2: the occurs root case, `arrowenv`, the `eqsolve` closure, costs and proof terms, `eqmgu`, the deferred `extorder` check, `givencheck` |
| 0010 | premise projections in `eqsolve`, `absquotient`, `budget`, `reifymemo` |
| 0011 | `extorder` checks whole cycle groups |
| 0012 | the soundness re-check: per-constructor `absquotient` opacity, nested-scope model reuse, scope-level abstract projections, context-stable premise projections, the `givencheck` environment |

## Checking a build

```bash
python3 tools/tcx.py freeze .build/release mylabel
```

```bash
python3 tools/tcx.py semtest --bin mylabel-<hash> --configs "occurs,fixsubst,eqsolve,extorder,arrowenv,eqmgu,givencheck,budget" --corpus all --jobs 3
```

`semtest` compares every type, binding, witness and diagnostic with the baseline. Expect `216/216 identical`. `tcx.py` resolves its paths relative to the repository's `research/` directory, so run it from a checkout of the research branch.
