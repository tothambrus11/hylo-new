# 5. Order-dependent memoization across cycle cuts

**Mechanism** (review names-1/names-2). While a declaration `X` is being typed (`declarationsOnStack`), two things can go wrong.

1. **Self-reference.** Evaluating something that refers back to `X` reports "refers to itself" and returns `.error`. The enclosing computation memoizes it permanently: the extendee of an extension, the type of a conformance, alias or binding, the types of its expressions, and the diagnostic.
2. **Silent skip.** Lookups skip any extension that is on the stack, with no diagnostic (baseline Typer.swift:4681). The result of the lookup is memoized too.

Which extension's extendee evaluation is entered first decides the outcome. It stays on the stack while the others are evaluated, and within one lookup that order is declaration order.

The cycles are often spurious. Member lookup always works out the extendee of *every* visible extension, even when a native member exists and even for extensions that declare no member of that name.

Examples:
- `type X = A.Foo; extension X {…}` reports a spurious cycle (n01), through the self-reference path. Evaluating `A.Foo` forces the extendee of `extension X`, which is `X`, on the stack. The memo that gets poisoned is that extendee (`#!`); `X` itself is fine. The reordered versions v02 and v04 are accepted.
- n05 goes wrong in two independent ways: through the extension's extendee (n05_nogiven) and through the given's conformance type (n05_givenonly).
- Swapping two extensions turns acceptance into rejection (n04 vs v2_swapped). This goes only through the silent skip: no "refers to itself" fires, and `early` plays no part.
- **The skip can also hide a competing candidate**, so the checker accepts a program that is ambiguous by its own rules. Take `struct A { type Foo = Int }` and `struct C { type Bar = A }`.
  - With `extension C.Bar { type Foo = Bool }` declared before `extension A.Foo { fun g() {} }`, the baseline accepts (amb_e2first).
  - In the other order it rejects `A.Foo` as not denoting a type (amb_e1first). A direct `extension A { type Foo = Bool }` is rejected the same way.
  - In one program, `A.Foo` in E1's extendee resolves to `Int`, while the same `A.Foo` in `fun k(y: A.Foo)` is rejected (amb_e2first_use).

So #5 is order-dependent **acceptance and rejection**, not only rejection of valid programs.

**Fix attempt (`cyclecut`): transactional speculation.**
- Member lookup needs an extension's extendee that is not yet memoized, or resolution needs a given's type that is not yet memoized. The typer:
  1. snapshots `(program, cache)`. These are value types, so taking the snapshot is O(1);
  2. evaluates;
  3. if the global counter of cuts changed meanwhile, restores the snapshot and treats the extension or given as not applicable for this query. Only the four "refers to itself" sites count as cuts.
- Only the snapshot restore has any effect. The `speculating`/`heldDiagnostics` machinery and the guarded `setType` calls are dead code, because `speculating` is never incremented.

Results on the 47 programs of `review/names/**` (diagnostic counts, baseline → `cyclecut`):

| Improved | Unchanged order-dependent |
|---|---|
| n01 2→0, n05 2→0, n17 3→2, v01 2→0, v06 2→0, v08 2→0 | t01, t02, t09, v2_swapped, v6_summon_swapped, n17 (one error left) |

No program in `names/**` gets more errors.

Identical on all 192 tests, but that holds **by construction**. Until the first cut, `cyclecut` runs the baseline's code, and the baseline reports "refers to itself" at every cut. So only programs the baseline rejects with that error can change, and the tests barely exercise the transaction path.

**Limitations of `cyclecut`, found with targeted programs** (`review/cyclecut-fix/`):
- **It accepts an ill-formed program the baseline rejects.**
  - The program, amb1: `extension A { type Me = A }; type X = A.Me; extension X { type Me = Int }`.
  - Under `cyclecut`, X resolves to A while `extension X` is skipped. Once X = A, that extension applies to A and `A.Me` is ambiguous (amb0, amb2), so the program has no consistent reading.
  - The baseline already accepts the reordered amb3. `cyclecut` extends this unsound skip rule to more declaration orders.
  - A sound version needs a post-check that every skipped extension really does not apply once its extendee is known.
- **Order dependence remains even without mutually dependent extendees.**
  - The cut counter is global and never reset, so a cut handled by an inner transaction also aborts every enclosing one.
  - casc1 (a use before `type X = A.Inner` and two `extension X`) still fails, with `Inner has no member h` and no cycle diagnostic. Declaring the use last (casc2) gives 0.
  - g1/g2 do the same with a conformance `given X is P`.
- **The rolled-back decision is final for the current query.** The query that saw the rollback is never re-checked, so the order dependence becomes a silently missing extension or given, followed by a misleading 'no member' or 'no coercion' error.
- **Cost.**
  - Discarded transactions are not memoized, so every later query repeats them, and each one costs several milliseconds (probably copy-on-write of the shared buffers).
  - perf_g16 (16 uses before the alias, extension and given): type-checking the user module takes 115 ms in the baseline and 6.9 s under `cyclecut` (824 discarded transactions). The stdlib is about 10% slower (noisy).
  - The fix is to memoize the "cut here" verdict per (declaration, stack base).

**A stronger variant (`cyclecut,cyclecutstack`)** also treats "skipped an extension that was already being typed when the transaction started" as a cut.
- It fixes t01, t02, t09 and v2_swapped.
- It newly rejects n02, n03, n04, t03, v1, v3, v4 and v5, which the baseline accepts.
- On the ambiguity case it only moves the acceptance to the other order: amb_e2first goes 0→2 and amb_e1first 2→0.

n02–n04, t01 and v2_swapped have **genuinely mutually dependent extendees**: E2's extendee needs a member of E1, and E1's extendee lookup must decide whether E2 applies. Any local rule picks *some* evaluation order, so the outcome stays order-dependent. Removing the dependence requires a language decision:
- (a) extendees are resolved in a pre-pass that does not consider extension members (simple, predictable, rejects some programs);
- (b) a fixpoint over extendee bindings (accepts the most, costs iterations).

The use-before-declaration cases (casc1, g1) and the missing consistency check (amb1) are implementation defects, not part of that language question.

`cyclecutstack` is kept only as a documented experiment.

`cyclecut` composes with `memberskip`: same results, since `memberskip` never skips an extension whose extendee is unmemoized.

(Summary table row for #5: "Results computed across a cycle cut or a skipped extension are memoized, so outcomes depend on declaration order | order-dependent rejection of valid programs **and acceptance of ambiguous ones** | partial fix `cyclecut`: 6 programs improved, but one ill-formed program newly accepted and large slowdowns on use-before-declaration programs".)

---

