# 1. Unrelated equalities make types interchangeable (unsound)

**Repro.** `soundness/bug-assoc-eq-two-links.hylo` and the variants `soundness/eqbug-1..4.hylo`:
```hylo
trait P { type X }
fun check<T>(x: T) {}
fun f<A, B, C, D where A is P, B is P, C is P, D is P, A.X == B.X, C.X == D.X>(x: D.X) {
  check<A.X>(x)   // accepted, but nothing relates A.X and D.X
}
```

**Which programs are affected.** The baseline proves an equality goal `L ~ R` whenever `R` is a side of some equality in scope.
- `L` can be any type when the goal is a call-site `where` requirement or a given's premise. That includes a type mentioned in no equality, or a concrete struct. Examples, with one equality each:
  - `fun f<V, W, D where V == W>() { g<D, V>() }`, where `g<T, U where T == U>`;
  - `fun f<V where V == S>() { g<Q, S>() }`;
  - `given <X where X == V> => X is P` proving `D is P`.
- When the goal comes from coercing an argument or annotation, `coerced()` first checks `canDeriveCoercions` on the outer pair. That check also requires `L` to be a side of some equality. This is why the repro above needs a second equality (`C.X == D.X`), and why the repro's comment "with a single equality the program is correctly rejected" holds only for that path.
- The sides can be generic parameters (`A == B, C == D`), associated types of unrelated traits (`D.Y`, eqbug-3), or nominal types.
- Types built from them are also interchangeable, for example `Box<D.X>` passed as `Box<A.X>`.
- The bogus derivation needs 7 resolution layers. At a depth cap of 6 or less, the program is rejected. When testing with small caps, use the impl binary with flags off: the frozen baseline binary ignores `HYLO_TC_MAXDEPTH`.

**The derivation the baseline accepts** (from the `trace` tool):
```
goal D.X ~ A.X  <- transitivity<T0 = D.X, T1 = ?e, T2 = A.X>
  premise ?e ~ A.X  <- the given A.X ~ B.X, coerced: unify (A.X ~ B.X) with (?e ~ A.X)
                        binds ?e := A.X, assumes B.X ~ A.X (proven by symmetry)
  premise D.X ~ ?e  <- reflexivity   (?e := D.X !)
result: transitivity<D.X, D.X, A.X>(reflexivity<D.X>)(coercion($A.X~B.X))(x)
```
The second premise is discharged last, because pending premises are discharged last-in, first-out.

**Root cause.** `Typer.match` (Typer.swift, "assume non-syntactic equalities between pairwise nested parts"):
- Unification of the witness's type with the goal records coercions for the parts that do not match.
- If those coercions may be derivable, it continues with `thread.environment.assuming(givens: gs)`. That environment **keeps the old substitutions and drops the `substitutions` that this very unification computed**.
- The success path (`coercions.isEmpty`) merges them correctly with `environment.substitutions.union(substitutions)`.

So a variable bound while proving one premise (`?e := A.X`) is free again when the next premise is proven, and can be bound to something else (`?e := D.X`).

Other paths checked, none of which drops substitutions:
- `threadContinuation`;
- `applyContinuation`;
- `formThread`, which reifies under the environment;
- `canDeriveCoercions`, which is only a necessary-condition filter.

**Fix (`fixsubst`).** Continue with `thread.environment.substitutions.union(substitutions)` in the coercion path as well.
- **Why `union` is safe.** `formThread` reifies both the witness and the query before matching, so the two tables bind disjoint variables.
- Identical on all 192 tests and on the standard library (same counters, no diagnostic).
- Rejects eqbug-1..4 at depth cap 7, in about 1.4 s each. At the default cap of 10 it is very slow: one run took 155 s and others exceeded 600 s (`eqbug-results.txt`).
- Rejects every other ill-typed variant tried: single equality, plain parameters, `Box<...>`, three equalities, and the generated `assocneg-N` workloads.
- Still accepts the valid control eqbug-5 (`B.X` used as `A.X` with `A.X == B.X`).

**Performance consequence.** With the bogus derivation gone, rejecting an ill-typed program means searching to the depth cap.
- eqbug-1 takes 3.3M matches and 155 s on an idle machine, and more than 600 s under load.
- Some ill-typed programs exceed the harness's 2.5 GB memory cap at the default depth instead of being rejected, for example `A == B, C == D` with `x: D` passed as `A`.

**Companion `eqrefute`** (meant to be used only together with `fixsubst`) restores fast rejection.
- **What it does.** Before searching for a closed equality goal `a ~ b` whose sides are atoms (generic parameters, associated types, or nominal types without arguments), it:
  1. collects the ground equality givens in scope, including the assumed ones;
  2. computes their equivalence classes with union-find, merging unifiable atoms;
  3. refutes the goal when `a` and `b` are in different classes.
- **When it gives up.**
  - a given can derive equalities from its own parameters: a quantified equality, a conditional equality (one with usings), or a `<T> T` head;
  - a fact has a structured side, where congruence could relate classes;
  - an assumed given still mentions variables, because assumed givens are not reified;
  - the goal has open variables.
- **It is not sound as implemented.** It rejects a valid program that the baseline and `fixsubst` both accept:
  ```hylo
  fun need<A, B where A == B>() {}
  trait P { type X; fun f<T, U where T == Self, T is P, T.X == U>() { need<X, U>() } }
  ```
  `fixsubst` derives `(Self::P).X ~ U` from `$t : (T::P).X ~ U` by a coercion that assumes `T ~ Self`. This works because unifying two associated types whose qualification is abstract unifies their qualification types (`TypeStore.unifiable(AssociatedType, AssociatedType)`).
- **Where the soundness argument fails.** The argument said that coercions between equality witnesses only require equalities between the sides, so every derivable equality lies within the closure. That is false for associated types: the premise can relate their qualifications. `equalityIsRefuted` treats associated types as atoms and never merges `(Self::P).X` with `(T::P).X`.
- **Required fix.** Give up when a side is an associated type with an abstract qualification, or close the union-find under qualification congruence. Add this program as a positive test, because the 192 tests do not cover it.
- **Also not handled.** With a structured side (`A == Box<B>, C == D`), `eqrefute` gives up, and the program still exceeds the memory cap.

Results:

| Program | Baseline | `fixsubst,eqrefute` |
|---|---|---|
| eqbug-1..4 | accepted (wrong), ≈1.4 s | rejected, ≈135 ms |
| assocneg-3 | accepted (wrong), 1.3 s | rejected, 133 ms |
| assocneg-8 | accepted (wrong), 4.4 s | rejected, 484 ms |
| single-equality call-site variants (`g<D, V>()`, `g<Q, S>()`) | accepted (wrong) | rejected, < 1 s |
| `A == Box<B>, C == D`, `x: D` as `A` | accepted (wrong) | exceeds the 2.5 GB memory cap |
| eqbug-5 (valid) | accepted, 140 ms | accepted, 137 ms |
| coercion-derivability-cache (valid) | accepted, 3.9 s | accepted, 3.9 s |
| `T == Self, T.X == U` ⊢ `X == U` (valid) | accepted | **rejected (wrong)** |

