# 4. Cyclic substitutions crash the compiler (no occurs check)

**Cause.** `TypeStore.unifiable` has no occurs check. Its variable cases bind a variable to a type that contains that variable. Reifying the resulting cyclic substitution recurses until the stack overflows: SIGSEGV, exit 139. The unifier is shared, so two paths reach the crash:
- implicit resolution, through `Typer.match`;
- ordinary expression inference, through the solver and `Typer.commit`.

**Repro, resolution.** `soundness/cyclic-query-segfault.hylo` (review t25). Givens `<U> U is P<U>` and `<T where T is P<S<T>>> T is R`, and a query `needR()` with an inferred `T`.
- `Typer.match` unifies the given's instantiated head `P<?u, ?u>` with the premise `P<?t, S<?t>>`. This binds `?u := ?t`, then `?t := S<?t>`, in match's local substitution table.
- No coercion is recorded, so match merges that table into the thread environment (`union`) and reifies the witness (Typer.swift:3762 on `tc/research`).
- That reify recurses forever.

**Repro, expression inference.** No givens are needed. Each of these crashes the baseline the same way (`review/occurs-fix/s2-tuple.hylo`, `s3-generic.hylo`):
- `fun same<T>(x: T, y: T) {}` with `let f = fun[](a) { same(a, (a, a)) }`;
- `same(a, mk(a))` with `mk<T>(x: T) -> S<T>`.

**Fix (`occurs`).** An occurs check in both variable cases of `TypeStore.unifiable`: binding a variable to a type that contains it, under the current local table, makes `unifiable` return `false`.
- Solver equalities then fail normally.
- Inside `Typer.match` the Bool result is ignored. A nested failure becomes a coercion on the nearest enclosing compound pair, which match then rejects.
- A top-level failure with no coercion would take match's success path with the binding missing. It is not reached in any test, but it should be guarded explicitly by reporting `(a, b)` as a coercion.

Results:
- t25 is rejected ("no coercion …") in tens of ms. The lambda repros give "cannot pass value of type `#!` …", a poor diagnostic but no crash.
- No program was found that still crashes with `occurs` on.
- Identical on all 192 tests.
- Cost: a walk of the bound type, only when it has variables. No measurable difference on the test suite.

**`occurs` is not invisible.** When a match would create a cycle *and* records a coercion, the baseline silently drops match's substitutions (including the cycle). It keeps a bogus derivation, then fails later with "not enough context to infer a type". `occurs` rejects that derivation instead ("no coercion …"), which changes inferred types and diagnostics: semtest reports MISMATCH on `review/occurs-fix/c1-cycle-plus-coercion.hylo` and `c3-accept-change.hylo`. No accept/reject flip was observed. Add these to the regression set.

**`fixsubst` depends on `occurs`.** `fixsubst` keeps match's substitutions on the coercion path, so the dropped cycle is now reified. With `fixsubst` alone, `c1`, `c3` and `c5-order2` crash (exit 139). With the baseline or with `occurs,fixsubst` they do not. `fixsubst` must never be enabled without `occurs`.

**Limits.** `occurs` prevents cycles created during unification. `SubstitutionTable.union`/`assign` remain unchecked; they are safe only because the inputs to match and to the solver are reified under the environment substitutions first. Latent gaps in `TypeStore.occurs`, none reachable from source so far:
- no `Bundle` case;
- the `hasVariable` early exit does not see `Arrow.environment`.

(Recommendation 1 should read: land `occurs` as a crash fix that also rejects some bogus derivations. Land it before, or together with, `fixsubst`.)

