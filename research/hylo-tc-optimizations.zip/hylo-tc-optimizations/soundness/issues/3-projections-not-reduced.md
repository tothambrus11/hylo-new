# 3. Associated-type projections in an instantiated generic signature are never reduced (incomplete, then explodes)

**Repro.** `soundness/assoc-eq-call-incomplete.hylo`, minimized:
```hylo
trait P { type X }
struct A {}
struct B { public memberwise init }
given A is P { type X = B }
fun f2<T where T is P, T.X == B>() {}
public fun main() { f2<A>() }     // valid, but rejected / runs out of memory
```

`let y: A.X = B()` works, so projection during name resolution is fine. The call `f2<A>()` needs the implicit arguments `(P<A>, ((A::P).X ~ B))`. `P<A>` is found (the given `A is P`), but the second goal stays `(A::P).X ~ B` and is never reduced to `B ~ B`.

**The defect.** It lies in how a generic signature is instantiated, not in the equality requirement specifically:
- Inside `f2`, `T.X` is resolved through the witness for `T is P`. That witness is a *reference to `f2`'s own where-clause binding* (`$i` in the trace), not the abstract witness. `typeOfImplementation` therefore builds an opaque `AssociatedType(X, qualification: ref(<f2's using>) : P<T>)`.
- Instantiating `f2<A>` substitutes `A` for `T` in the types only, so the qualification is still `ref(<f2's using>) : P<A>`. That reference is meaningless at the call site.
- `TypeStore.unifiable(AssociatedType, AssociatedType)` unifies two projections only when one qualification is `.abstract`, so this projection unifies with nothing else.
- Nothing links the using declaration to the premise `$0` that witnesses it: `introduce(types:usings:)` stores only the usings' types. The witness found for `$0` is therefore never substituted anywhere.
- The printer shows only `(A::P).X`, so projections with different qualifications print identically. An error message or trace showing `(A::P).X` does not reveal which witness it holds.

The equality requirement is one instance. The same failure, fast and on the baseline too, happens with no equality at all:
- `fun f3<T where T is P>(x: T.X)` called as `f3<A>(B())`: "cannot pass value of type 'B' to parameter '(A::P).X'".
- `fun f6<T where T is P>() -> T.X` with `let y: B = f6<A>()`: "no coercion from '(A::P).X' to 'B'".
- A generic caller, `fun g<U where U is P>(y: U.X) { h<U>(y) }` with `h<T where T is P>(x: T.X)`: "cannot pass value of type '(U::P).X' to parameter '(U::P).X'".

Only reflexive requirements (`T.X == T.X`) are discharged.

**The blow-up.** Without `eqrefute`, the resolver searches the equality built-ins until the cap:
- caps 5–7: 7.3k → 23k → 82k matches, "no coercion" error;
- default cap 10: runs out of memory, after more than 4.8 GB (review t08/t24), on the baseline and with `fixsubst` alone.

With `eqrefute`, the blow-up disappears: both sides are atoms in different classes, so the goal is refuted immediately (292 matches, about 30 ms, "no coercion" at any cap). The rejection is still wrong, because `eqrefute` refutes an equality that is true and that this procedure cannot derive.

**Interaction with #1.** In a generic caller, `fun h<U where U is P, U.X == B>() { f2<U>() }`, the baseline *accepts* the call (0 diagnostics, 92k matches, 1.7 s). The only reason is a bogus derivation through symmetry and transitivity with an unbound middle variable, which is the bug #1 path. `h`'s own given, printed as the same `(U::P).X ~ B`, does not match the goal directly. Under `fixsubst,eqrefute` the call is rejected, and with `fixsubst` alone it runs out of memory. So landing `fixsubst`/`eqrefute` without this fix turns an accidental acceptance of a valid program into a rejection.

**Fix (not implemented): dependent requirements.**
- Record, for each premise of an instantiated signature, which using declaration it witnesses.
- When premise `$i` is solved with witness `w`, substitute `w` for references to that using throughout the instantiated callee type, in the head (parameter and result types) as well as the remaining premises. Then reduce each projection whose qualification is now a conformance declaration: `(A::P).X` becomes `(A::<given A is P>).X = B`. In a generic caller, `w` is the caller's own binding, so `h<U>`'s `U.X` and `g`'s `U.X` become the same type.
- This needs two changes:
  - Premises are currently discharged last-first (`threadContinuation` pops `givens.last`), so the equality is attempted before the conformance it depends on. Discharge them in forward order, or rewrite pending goals' types when an earlier premise is solved.
  - The head is matched before any premise is discharged, so the substitution must happen before argument and result constraints are solved, or those constraints must be re-checked afterwards.
- The reduction must run before `equalityIsRefuted`, or `eqrefute` will keep refuting these goals.
- Merely "normalizing associated types with concrete qualifications through the conformance" is not enough: it does not cover generic callers, whose qualification type is `P<U>`.
- Unverified caveat: `typeOfImplementation` reads an implementation's declared type without applying a generic conformance's type arguments, so `type X = T` in `given <T> => Box<T> is P` may also need instantiation. Projections such as `Box<B>.X` currently fail earlier, at type-expression resolution, so this could not be tested.

