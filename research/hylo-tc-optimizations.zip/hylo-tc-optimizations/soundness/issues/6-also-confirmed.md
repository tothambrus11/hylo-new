# Also confirmed

- **`negative/illegal-enum-case.hylo` crashes the typer** (force unwrap in `declaredType(of: EnumCaseDeclaration)`, Typer.swift ≈1367). It is reachable only from `tc-bench`, because the driver stops after scoping errors. Fix: return `.error` when the case has no enclosing enum.


