# Review verdicts

| # | Defect | Cause (judge) | Fix (judge) | Most important corrections |
|---|---|---|---|---|
| 1 | Bogus equality derivations (`fixsubst`, `eqrefute`) | confirmed-with-corrections | sound-but-insufficient | A **single** equality suffices at call sites and given premises: `g<D, V>()` with only `V == W` is accepted. Congruence extends it (`Box<D.X>` as `Box<A.X>`). **`eqrefute` is unsound**: it rejects the valid `v-abs-7.hylo`, because associated types with an abstract qualification unify through their qualification. Some fixed configurations exhaust memory instead of rejecting. |
| 2 | Equality chains need a procedure | confirmed-with-corrections | sound-but-insufficient | Rejection beyond 4 links is a **depth-cap cliff**: a genuine proof costs about 2 match steps per link, so trans-5 needs a cap of 12. A procedure needs decomposition (injectivity of nominal constructors), not only congruence closure. `canDeriveCoercions` pre-filters congruence-derivable goals. |
| 3 | Projections not reduced (was: `where T.X == B`) | partially-wrong | sound-but-insufficient | Broader than stated: **any associated-type projection in an instantiated generic signature fails** (parameter types, return types, generic callers). The qualification is a reference to the callee's using, not "abstract". `eqrefute` does apply, wrongly, to generic callers. The proposed fix does not reach them. |
| 4 | Cyclic substitution crash (`occurs`) | confirmed-with-corrections | sound-but-insufficient | `occurs` is **not** invisible: it changes inferred types and diagnostics on some non-crashing programs. **`fixsubst` alone introduces new SIGSEGVs** and requires `occurs`. The crash is also reachable from plain expression inference. |
| 5 | Order-dependent memoization (`cyclecut`) | confirmed-with-corrections | **unsound** | `cyclecut` **accepts an ill-formed (ambiguous) program the baseline rejects** (`amb1.hylo`). Its skip path accepts programs that are ambiguous by the checker's own rules, depending on order. Rolled-back transactions are expensive and repeated. The 192-test oracle does not exercise it. |

Reviewer verdicts:
- §1: confirmed-with-corrections, partially-wrong
- §2: confirmed-with-corrections, confirmed-with-corrections
- §3: partially-wrong, partially-wrong
- §4: confirmed-with-corrections, confirmed-with-corrections
- §5: confirmed-with-corrections, partially-wrong

I re-ran four of the confirmed issues myself:

| Repro | Baseline | Fixed configuration |
|---|---|---|
| `review/eqsubst-cause/c01-single-eq-call.hylo` | accepted (wrong) | `fixsubst,eqrefute` rejects |
| `review/eqsubst-fix/v-abs-7.hylo` (valid) | accepted | `fixsubst` accepts; `fixsubst,eqrefute` rejects (wrong) |
| `review/occurs-fix/c1-cycle-plus-coercion.hylo` | 1 diagnostic | `fixsubst` exits 139 (SIGSEGV); `occurs,fixsubst` gives 1 diagnostic |
| `review/cyclecut-fix/amb1.hylo` (ambiguous) | rejected | `cyclecut` accepts (wrong) |

**Tracing tool.** `HYLO_TC_EXPERIMENTS=trace` prints, for every completed resolution, the minimal results and the derivation log of each completed thread.

---

