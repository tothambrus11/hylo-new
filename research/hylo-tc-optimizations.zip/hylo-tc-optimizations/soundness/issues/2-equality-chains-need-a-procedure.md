# 2. Equality chains need an equality procedure, not search

Bug #1 also explains why valid equality chains were "fast". The baseline's proofs of them are bogus, with the right conclusion by luck. For `trans-4`, `T0 ~ T4` is "proved" without ever using `T1 ~ T2`: `transitivity<T0, ?e, T4>` proves `?e ~ T4` by coercing `T2 ~ T3` (assuming `T3 ~ T4`), and then, through the same dropped binding, closes `T0 ~ ?e` by reflexivity or by `T0 ~ T1`. These bogus proofs have a fixed size (about 7 match steps, 8 for the call) whatever the chain length, so the baseline cost stays nearly flat.

With `fixsubst`, every proof is genuine, and a genuine proof costs about **2 match steps per link**: 2n+2 for trans-n, 2n+1 for assoceq-n. The resolution "depth" cap bounds the **size** of a derivation, not its height: each BFS layer advances every thread by one match, and pending premises are discharged one after another. Each extra step multiplies the work by about 4-5:

| Chain | Baseline (bogus proof) | `fixsubst` (genuine search) |
|---|---|---|
| trans-3 | 731 ms, 30k matches | 745 ms, 30k matches (needs cap 8) |
| trans-4 | 918 ms, 35k matches | **13-20 s, 640k matches** (needs cap 10; cap 9 rejects) |
| trans-5 | 1.2 s, 41k matches | needs 12 steps, so rejected by the default cap of 10. Under the standard 2.5 GB limit it **crashes out of memory** (about 35 s). With the limit raised: 51-79 s, rejected |
| assoceq-5, trans-8 | 2.7 s / 1.9 s | need 11 and 18 steps. **Out-of-memory crash** after about 35 s |

The search space explored per layer is the same with and without `fixsubst` (for example trans-3 at cap 8: 29.8k vs 29.7k matches). The slowdown comes entirely from having to go deeper. The existing performance flags do not change this: on trans-4, `loopcheck` halves the matches (337k) and `eqrefute` leaves them unchanged (640k).

**Conclusion.** `fixsubst` alone is correct but makes the equality fragment unusable:
- chains of 3-4 links become slow;
- chains of 5 or more links are rejected outright by the cap, or crash the compiler, however fast the search is.

Equalities need a decision procedure that answers an equality subgoal in one step, instead of SLD search with built-in symmetry and transitivity givens. Requirements on that procedure:
- **Theory.** Congruence closure over the equalities in scope, **plus decomposition (injectivity) of nominal type constructors**. `match` poses the innermost mismatched parts as subgoals. For example, `Box<A> == Box<B>, Box<A> is P` needs `A ~ B` to use `P<Box<B>>`, and congruence alone does not give that (`decomp-2`, `quant-4` are rejected today in every configuration). Clash detection between distinct constructors gives the negative answers.
- **Atoms.** Associated types are opaque atoms identified by their qualifying conformance witness, not functions of their base type. `T == U` must not give `T.X == U.X` (`negative/associated-type-inequality.hylo`).
- **Pre-filter.** It must also replace the "may a coercion be derivable" test in `canDeriveCoercions`/`coerced`. That test requires each side to unify with a side of some equality given, so it rejects congruence-derivable goals before any search: `C == Box<A>, A == B` with `x: C` used as `Box<B>` is rejected after 1 match (`quant-2`, `quant-2c`).
- **Ground goals.** Union-find decides `a ~ b` and produces the proof term from the path.
- **Open goals.** Unify syntactically, then check the mismatched pairs against the closure. In general this is rigid E-unification, not a single unification against a class representative, so validate any change in inferred bindings with the oracle.

This is a design change: the proof terms change, and equality subproofs no longer count toward the depth cap. It should land together with `fixsubst`. `eqrefute` above is only a narrow first step towards the negative half. It works only when **every** equality in scope is between atoms, and it gives up for all goals as soon as any structured, conditional or quantified equality is visible, even an unrelated one. For example, eqbug-1 plus an unrelated `Box<Z> == W` is no longer refuted, and with `fixsubst,eqrefute` it crashes out of memory (`review/eqchain-fix/eqbug1-struct.hylo`).

