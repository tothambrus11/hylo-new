# Hylo type-checker optimizations: patches, reports and evidence

This archive collects everything about the type-checker work on `tothambrus11/hylo-new`: the patch series, the reports, one detailed document per technique, one per soundness issue, and the evidence (oracle results, benchmarks, the reviewers' programs). Start with `REPORT.html`.

## Contents

| Path | What it is |
|---|---|
| `REPORT.html` | The overview report. It covers every technique (how it works, why it is sound, what it speeds up, what it costs), the results table and the limitations. Open it in a browser. |
| `patches/` | `0001`–`0012`, a `git format-patch` series on branch `tc/research`. `patches/APPLY.md` explains how to apply, build and run it. |
| `techniques/` | One document per flag, with the same four sections as the report but in full detail. `techniques/README.md` is the index with the status of every flag. |
| `soundness/issues/` | One document per soundness issue: the baseline issues (1–5), the final configuration with the review-2 findings (`0-final-configuration.md`), and the re-check on context and undecidability (`8-…`). |
| `soundness/recheck/` | The last re-check, on undecidability and context-dependent resolution, with its test programs. |
| `soundness/soundness-full.md` | The same soundness material as one file. |
| `soundness/review1/`, `soundness/review2/` | The two adversarial reviews: the programs the reviewers wrote, their outputs, and the judges' re-runs (`results.json` in `review2`). |
| `validation/` | The evidence for the final configuration. `oracle-final-config.txt` is the semantic oracle on the corpus. `regress-final.md` and `.jsonl` re-run all 520 review programs. `bench-final.md` and `.jsonl` hold the timings. |
| `repros/` | Minimal reproducers of the baseline bugs, and the order-dependence pairs (`repros/order-dependence/`). |
| `tools/` | `tcx.py` (freeze, semtest, experiment queue; see `tcx-README.md`), `bench-final.py`, `regress.py`, and the workflow scripts used for the reviews. |
| `history/` | Earlier write-ups: the round-1 report (some of its claims were later corrected; see `ROUND2.md`), round 2, round 3, the per-flag benchmark of round 3, and the agent handoff notes. |

## Recommended configurations

Flags are runtime switches: `HYLO_TC_EXPERIMENTS=a,b,…`.

- **FIX** (correctness fixes only): `occurs,fixsubst,eqsolve,extorder,arrowenv,eqmgu,givencheck,budget`
- **FULL** (fixes and speed-ups): FIX + `symindex,coesrc,traitindex,memberskip,unify,index,absmodel,absquotient,typevec,reifymemo`

Both produce output identical to the baseline on the 216-file corpus (192 compiler tests and 24 workloads). On the 520 review programs, FULL has no crash or out-of-memory, against 21 crashes and 42 timeouts for the baseline.

## Techniques by area

| Area | Speed-ups (output unchanged) | Correctness fixes |
|---|---|---|
| Choosing candidate givens | `index`, `coesrc` | |
| Proving that resolution fails | `absmodel`, `absquotient` | `budget` |
| Equality constraints | `eqsolve`, `eqmgu`, `absquotient` | `fixsubst`, `eqsolve`, `eqmgu` |
| Member lookup | `memberskip`, `traitindex` | `extorder`, `givencheck` |
| Type representation | `typevec`, `unify`, `reifymemo`, `symindex` | `occurs`, `arrowenv` |
| Retired (unsound or no gain) | `names`, `loopcheck`, `solver`, `coercememo` | `eqrefute`, `cyclecut` |

## Soundness issues of the baseline

| # | Issue | Document | Fixed by |
|---|---|---|---|
| 1 | Unrelated equalities make types interchangeable (bogus equality derivations) | `soundness/issues/1-…` | `fixsubst` + `eqsolve` |
| 2 | Equality chains explode or hit the depth cap | `soundness/issues/2-…` | `eqsolve`, `eqmgu` |
| 3 | Associated-type projections in instantiated signatures are not reduced | `soundness/issues/3-…` | partly, by `eqsolve`'s premise projections |
| 4 | Cyclic substitutions crash the compiler | `soundness/issues/4-…` | `occurs`, `arrowenv` |
| 5 | Order-dependent memoization across cycle cuts | `soundness/issues/5-…` | `extorder`, `givencheck` |
| — | Defects found in the fixes themselves by review 2 and by the re-check | `soundness/issues/0-final-configuration.md`, `soundness/recheck/README.md` | patches 0009–0012 |

## Literature

`REPORT.html` has a literature survey with 41 references, each marked with how it was checked. `literature/` holds the two full literature studies made before the implementation (about 60 sources, with notes on each one's relevance to Hylo) and the list of papers consulted. The PDFs themselves are not included, for copyright reasons.
